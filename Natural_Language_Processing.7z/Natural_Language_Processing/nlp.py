# Natural Language Processing

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import preprocessing
# Importing the dataset
dataset = pd.read_csv('nlu.csv', encoding='ISO-8859-1')
le = preprocessing.LabelEncoder()
dataset.iloc[:,1] = le.fit_transform(dataset.iloc[:,1]) 
#print(dataset.iloc[:,1])
#data_inverse = le.inverse_transform(dataset.iloc[:,1])
#print(data_inverse


word_corpus = [] #corpus of unique words from nlu.csv 1st column
import csv
from nltk.tokenize import sent_tokenize, word_tokenize 
with open('nlu.csv') as csvfile:
	readCSV = csv.reader(csvfile, delimiter=',')
	for row in readCSV:
		token_piece = word_tokenize(row[0])
		for i in range (len(token_piece)):
			word_corpus.append(token_piece[i])
			
word_corpus = list(set(word_corpus))
word_corpus.sort() 	


for j in range(len(word_corpus)):	
	with open('word_corpus.csv', 'a', newline= '' ) as writeFile:
		writer = csv.writer(writeFile)
		word_corpus_jj = [word_corpus[j].strip(),j]
		writer.writerow(word_corpus_jj)	
	writeFile.close()
#print(sent_tokenize(text)) 
#print(word_tokenize(text))
# get word-vector
def getWordVector(word):
	vector = 0
	with open('word_corpus.csv','r',newline='') as readFile:
		reader = csv.reader(readFile)
		for row in reader:
			if row[0] == word:
				vector = row[1]
	return vector	

#encode and update
with open('nlu.csv','r',newline='') as readFile:
	reader = csv.reader(readFile)
	for row in reader:
		word_vector_val = getWordVector(row[0])
		print(row[0]+" => "+word_vector_val)



		

	
	




