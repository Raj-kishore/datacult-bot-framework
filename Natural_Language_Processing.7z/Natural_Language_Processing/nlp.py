# Natural Language Processing

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import preprocessing
# Importing the dataset
dataset = pd.read_csv('nlu.csv', encoding='ISO-8859-1')
le = preprocessing.LabelEncoder()
dataset.iloc[:,1] = le.fit_transform(dataset.iloc[:,1]) 
#print(dataset.iloc[:,1])
#data_inverse = le.inverse_transform(dataset.iloc[:,1])
#print(data_inverse)
